package com.todoapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.todoapp.model.User;
import com.todoapp.utils.JDBCUtils;

public class UserDao {

	public int registerEmployee(User employee) throws ClassNotFoundException {
		String INSERT_USERS_SQL = "INSERT INTO users" + "  (first_name, last_name, username, password) VALUES "
				+ " (?, ?, ?, ?);";
		String SELECT_USERS_SQL = "SELECT * from users where username=?";
		int isexist=0;

		try (Connection connection = JDBCUtils.getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement0 = connection.prepareStatement(SELECT_USERS_SQL)) {
			preparedStatement0.setString(1, employee.getUsername());
			ResultSet resultset = preparedStatement0.executeQuery();
			 if (resultset.next()) {
			        isexist = 1; // User exists
			    } else {
			        isexist = 0; // User does not exist
			    }
		} catch (SQLException e) {
			// process sql exception
			JDBCUtils.printSQLException(e);
		}
		int result = 0;
		if (!(isexist>0)) {

			try (Connection connection = JDBCUtils.getConnection();
					// Step 2:Create a statement using connection object
					PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
				preparedStatement.setString(1, employee.getFirstName());
				preparedStatement.setString(2, employee.getLastName());
				preparedStatement.setString(3, employee.getUsername());
				preparedStatement.setString(4, employee.getPassword());

				System.out.println(preparedStatement);
				// Step 3: Execute the query or update query
				result = preparedStatement.executeUpdate();

			} catch (SQLException e) {
				// process sql exception
				JDBCUtils.printSQLException(e);
			}
		}
		return result;
	}

}
